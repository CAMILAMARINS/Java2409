let i, n = 21
var conta_atual = 0 ,conta_antiga

for( i = 1 ; i < n; i++ ){

    conta_atual= (conta_atual * 2) + 1 

    console.log(conta_atual)

}
