let n, i
var soma

n= Number (prompt("Digite número de elefantes:"))

for( i = 1 ; i < n; i++ ){

    console.log(`${i} elefante(s) incomoda(m) muita gente`)
    
    soma= i + 1
    console.log(`${soma} elefantes incomodam muito mais`)
}